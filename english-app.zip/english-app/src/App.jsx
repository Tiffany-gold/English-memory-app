import { useState, useRef } from "react";

const LESSONS = [
  {
    id: 1,
    title: "What's in Your School Survival Kit?",
    subtitle: "여러분의 학교 생존 키트에는 무엇이 있나요?",
    sentences: [
      { id: 1, en: "Hello, everyone! Welcome to my class!", kr: "안녕하세요, 여러분! 제 수업에 오신 것을 환영합니다!" },
      { id: 2, en: "I'm Ms. Seo, your English teacher.", kr: "저는 서 선생님이고, 여러분의 영어 선생님이에요." },
      { id: 3, en: "Today is the first day of middle school.", kr: "오늘은 중학교의 첫날이네요." },
      { id: 4, en: "Are you nervous?", kr: "긴장되나요?" },
      { id: 5, en: "I'm also nervous, but I feel okay with this box.", kr: "저도 긴장돼요, 하지만 이 상자가 있어서 괜찮아요." },
      { id: 6, en: "This box is my school survival kit.", kr: "이 상자는 나의 학교 생존 키트이에요." },
      { id: 7, en: "I have many things in it.", kr: "저는 그것 안에 많은 것을 가지고 있답니다." },
      { id: 8, en: "First, I have some sticky notes.", kr: "첫째로, 저는 붙임쪽지들을 가지고 있어요." },
      { id: 9, en: "I use them on the first day.", kr: "저는 첫날에 그것들을 사용한답니다." },
      { id: 10, en: "I write your names and remember them.", kr: "저는 여러분들의 이름들을 적어요, 그리고 그것들을 기억해요." },
      { id: 11, en: "Next, I have some candy.", kr: "다음으로, 저는 사탕들을 가지고 있어요." },
      { id: 12, en: "These are for you.", kr: "이것들은 여러분들을 위한 거예요." },
      { id: 13, en: "They're sweet, like your smiles.", kr: "그것들은 달콤합니다, 여러분의 미소들처럼." },
      { id: 14, en: "Ms. Seo: Now, what do you want in your school survival kit?", kr: "이제, 무엇을 원하나요, 여러분들의 학교 생존 키트 안에는?" },
      { id: 15, en: "Somin: A mirror! I look in the mirror and say, Just be you!", kr: "거울이요! 저는 거울을 봐요, 그리고 말해요, 그냥 너답게 해!" },
      { id: 16, en: "Jiwon: For me, a stress ball.", kr: "저는, 스트레스 푸는 공이요." },
      { id: 17, en: "I hold the ball tightly.", kr: "저는 그 공을 꽉 쥐어요." },
      { id: 18, en: "Then my stress goes away.", kr: "그러면 나의 스트레스가 사라져요." },
      { id: 19, en: "Mike: An eraser! It erases my mistakes.", kr: "지우개요! 그것은 저의 실수들을 지워 줘요." },
      { id: 20, en: "I start all over again!", kr: "저는 처음부터 다시 시작해요!" },
      { id: 21, en: "Emily: I need a Band-Aid!", kr: "저는 반창고가 필요해요!" },
      { id: 22, en: "My feelings get hurt sometimes.", kr: "저의 감정들이 때때로 상처 받아요." },
      { id: 23, en: "But with the Band-Aid, I'm okay.", kr: "그러나, 이 반창고가 있어서, 저는 괜찮아요." },
      { id: 24, en: "Ms. Seo: Great! Now make your own survival kit.", kr: "좋아요! 이제 여러분 자신의 생존 키트를 만들어 보세요." },
      { id: 25, en: "Let's have a great year!", kr: "좋은 한 해를 보내도록 합시다!" },
    ]
  },
  {
    id: 2,
    title: "그때 그리고 지금",
    subtitle: "Then and Now",
    sentences: [
      { id: 1, en: "Meet Jihun and Minjun.", kr: "지훈이와 민준이를 만나 보세요." },
      { id: 2, en: "They are 12 years old.", kr: "그들은 열두 살입니다." },
      { id: 3, en: "They both love comics and music, but they live in different times.", kr: "그들은 둘 다 만화와 음악을 좋아해요, 하지만 다른 시대에 살고 있어요." },
      { id: 4, en: "Jihun lives in 1995, and Minjun lives in the present.", kr: "지훈이는 1995년에 살아요, 그리고 민준이는 현재에 살아요." },
      { id: 5, en: "Let's look at their lives.", kr: "살펴봅시다, 그들의 생활을." },
      { id: 6, en: "It is morning. The alarm clock is going off. Jihun gets up.", kr: "아침이에요. 자명종이 울리고 있어요. 지훈이가 일어나요." },
      { id: 7, en: "He looks out the window and checks the weather. It is raining.", kr: "그는 창밖을 내다봐요, 그리고 날씨를 확인해요. 비가 오고 있어요." },
      { id: 8, en: "He puts his books and lunchbox in his backpack and grabs his umbrella.", kr: "그는 그의 책과 도시락을 책가방 안에 넣어요, 그리고 우산을 집어 들어요." },
      { id: 9, en: "As he leaves, he says, Ugh! My backpack is so heavy!", kr: "그가 출발하면서, 그는 말해요, 욱! 내 책가방은 정말 무거워!" },
      { id: 10, en: "Loud hip-hop music is coming from Minjun's smartphone. Minjun wakes up.", kr: "요란한 힙합 음악이 민준이의 스마트폰에서 나오고 있어요. 민준이가 잠에서 깨요." },
      { id: 11, en: "He asks Al Joe, Hey Joe, what's the weather like today?", kr: "그는 Al Joe에게 물어요, 이봐 Joe, 날씨가 어때, 오늘?" },
      { id: 12, en: "It's sunny, says Joe. Then, Minjun gets ready for school.", kr: "화창해요, Joe가 말해요. 그리고 나서, 민준이는 학교에 갈 준비를 해요." },
      { id: 13, en: "He simply picks up his tablet.", kr: "그는 그저 그의 태블릿을 집어 들어요." },
      { id: 14, en: "There are many coins in his pocket. He takes out 200 won and gets on the bus.", kr: "그의 주머니 안에 많은 동전이 있어요. 그는 이백 원을 꺼내요, 그리고 버스에 타요." },
      { id: 15, en: "Lucky him! There is an empty seat on the bus.", kr: "그는 운이 좋아요! 버스에 빈자리가 있네요." },
      { id: 16, en: "Jihun sits down and reads his comic book.", kr: "지훈이는 앉아요, 그리고 그의 만화책을 읽어요." },
      { id: 17, en: "Minjun is taking the bus.", kr: "민준이는 버스에 타고 있어요." },
      { id: 18, en: "He is holding a bus card in his hand.", kr: "그는 그의 손에 버스 카드를 들고 있어요." },
      { id: 19, en: "There are many people on the bus. There is no seat for him, but that is okay.", kr: "버스에 많은 사람들이 있어요. 그를 위한 앉을 자리는 없어요, 그러나 괜찮아요." },
      { id: 20, en: "He reads his favorite webtoon on his smartphone.", kr: "그는 그의 스마트폰으로 가장 좋아하는 웹툰을 읽어요." },
      { id: 21, en: "At night, Jihun is listening to his favorite radio show.", kr: "밤에, 지훈이는 그가 가장 좋아하는 라디오 프로그램을 듣고 있어요." },
      { id: 22, en: "He records songs from the radio on a tape. There are many great songs on the tape.", kr: "그는 라디오에서 나오는 노래를 테이프에 녹음해요. 그 테이프에 좋은 노래가 많이 있어요." },
      { id: 23, en: "Sometimes, he writes a letter to the DJ and requests a song.", kr: "때때로, 그는 DJ에게 편지를 써요, 그리고 노래를 신청해요." },
      { id: 24, en: "Minjun is using his tablet and writing a rap song.", kr: "민준이는 그의 태블릿을 사용하고 있어요, 그리고 랩 노래를 쓰고 있어요." },
      { id: 25, en: "Later, he shares the song on social media.", kr: "나중에, 그는 그 노래를 소셜 미디어에 공유해요." },
      { id: 26, en: "He gets likes from people around the world.", kr: "그는 전 세계의 사람들로부터 좋아요를 받아요." },
      { id: 27, en: "Minjun checks his DMs before bedtime.", kr: "민준이는 자기 전에 그의 DM을 확인해요." },
      { id: 28, en: "One message says, U R AMAZING!", kr: "한 메시지는 쓰여 있어요, 너는 굉장해!" },
    ]
  }
];

const MODES = [
  { id: "blank", label: "빈칸 채우기", emoji: "✏️" },
  { id: "order", label: "단어 순서", emoji: "🔀" },
  { id: "dictation", label: "받아쓰기", emoji: "🎧" },
  { id: "typing", label: "전체 타이핑", emoji: "⌨️" },
];

function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function normalize(str) {
  return str.toLowerCase().replace(/[^a-z0-9\s]/g, "").replace(/\s+/g, " ").trim();
}

// ── AI 사진 업로드 화면 ──────────────────────────────
function PhotoUploader({ onDone, onBack }) {
  const [stage, setStage] = useState("upload"); // upload | preview | editing | done
  const [imageData, setImageData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [extracted, setExtracted] = useState([]);
  const [title, setTitle] = useState("");
  const fileRef = useRef();

  const handleFile = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setImageData(reader.result);
      setStage("preview");
    };
    reader.readAsDataURL(file);
  };

  const extractText = async () => {
    setLoading(true);
    setError("");
    try {
      const base64 = imageData.split(",")[1];
      const mediaType = imageData.split(";")[0].split(":")[1];
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{
            role: "user",
            content: [
              {
                type: "image",
                source: { type: "base64", media_type: mediaType, data: base64 }
              },
              {
                type: "text",
                text: `이 교과서/학습자료 이미지에서 영어 문장들을 추출해주세요.

규칙:
1. 영어 본문 문장만 추출 (번호, 한국어 번역, 문법 설명 제외)
2. JSON 배열로만 응답. 다른 텍스트 없이.
3. 형식: [{"en": "English sentence", "kr": "한국어 번역"}, ...]
4. 한국어 번역이 있으면 함께, 없으면 kr을 ""로
5. 짧은 단어/제목/문법 설명은 제외하고 완전한 문장만

JSON만 응답하세요.`
              }
            ]
          }]
        })
      });
      const data = await response.json();
      const text = data.content.map(c => c.text || "").join("");
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      const withIds = parsed.map((s, i) => ({ ...s, id: i + 1 }));
      setExtracted(withIds);
      setStage("editing");
    } catch (err) {
      setError("텍스트 추출에 실패했어요. 다시 시도해주세요.");
    }
    setLoading(false);
  };

  const updateSentence = (idx, field, val) => {
    setExtracted(prev => prev.map((s, i) => i === idx ? { ...s, [field]: val } : s));
  };

  const removeSentence = (idx) => {
    setExtracted(prev => prev.filter((_, i) => i !== idx).map((s, i) => ({ ...s, id: i + 1 })));
  };

  const finish = () => {
    if (!title.trim()) { setError("자료 이름을 입력해주세요"); return; }
    if (extracted.length === 0) { setError("문장이 없어요"); return; }
    onDone({ id: Date.now(), title: title.trim(), subtitle: "내가 추가한 자료", sentences: extracted });
  };

  return (
    <div style={S.wrap}>
      <button style={S.backBtn} onClick={onBack}>← 단원 선택</button>
      <div style={S.tag}>📸 AI 자료 추가</div>
      <h1 style={S.title}>사진으로 자료 추가</h1>

      {stage === "upload" && (
        <div>
          <p style={S.sub}>교과서나 학습자료를 찍어서 올리면<br/>AI가 자동으로 문장을 추출해요</p>
          <div style={S.uploadBox} onClick={() => fileRef.current.click()}>
            <div style={{ fontSize: 48 }}>📷</div>
            <div style={{ fontWeight: 700, color: "#3949ab", marginTop: 8 }}>사진 선택하기</div>
            <div style={{ fontSize: 13, color: "#9fa8da", marginTop: 4 }}>교과서, 프린트물, 문제지 등</div>
          </div>
          <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={handleFile} />
        </div>
      )}

      {stage === "preview" && (
        <div>
          <img src={imageData} style={{ width: "100%", borderRadius: 12, marginBottom: 16 }} alt="uploaded" />
          <p style={S.sub}>이 사진에서 영어 문장을 추출할게요</p>
          {error && <div style={S.errorBox}>{error}</div>}
          <button style={S.bigBtn} onClick={extractText} disabled={loading}>
            {loading ? "🤖 AI가 읽는 중..." : "🤖 AI로 문장 추출하기"}
          </button>
          <button style={{ ...S.outlineBtn, marginTop: 10 }} onClick={() => setStage("upload")}>다시 선택</button>
        </div>
      )}

      {stage === "editing" && (
        <div>
          <div style={{ background: "#e8f5e9", borderRadius: 12, padding: "12px 16px", marginBottom: 16, fontSize: 14, color: "#2e7d32", fontWeight: 600 }}>
            ✅ {extracted.length}개 문장을 찾았어요! 확인하고 수정해보세요.
          </div>
          <input
            style={S.titleInput}
            placeholder="자료 이름 입력 (예: Lesson 3 본문)"
            value={title}
            onChange={e => setTitle(e.target.value)}
          />
          <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 16 }}>
            {extracted.map((s, i) => (
              <div key={i} style={S.editCard}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                  <span style={{ fontSize: 12, fontWeight: 700, color: "#4f7cff" }}>{i + 1}번</span>
                  <button onClick={() => removeSentence(i)} style={{ background: "none", border: "none", color: "#e53935", cursor: "pointer", fontSize: 16 }}>🗑</button>
                </div>
                <input
                  style={S.editInput}
                  value={s.en}
                  onChange={e => updateSentence(i, "en", e.target.value)}
                  placeholder="영어 문장"
                />
                <input
                  style={{ ...S.editInput, marginTop: 6, color: "#5c6bc0" }}
                  value={s.kr}
                  onChange={e => updateSentence(i, "kr", e.target.value)}
                  placeholder="한국어 번역 (선택)"
                />
              </div>
            ))}
          </div>
          {error && <div style={S.errorBox}>{error}</div>}
          <button style={S.bigBtn} onClick={finish}>✅ 저장하고 학습 시작</button>
        </div>
      )}
    </div>
  );
}

// ── 연습 컴포넌트들 ──────────────────────────────────
function BlankMode({ sentence, onResult }) {
  const words = sentence.en.split(" ");
  const blankCount = Math.max(1, Math.floor(words.length / 3));
  const blankIndices = useRef(shuffleArray([...Array(words.length).keys()]).slice(0, blankCount)).current;
  const [answers, setAnswers] = useState({});
  const [checked, setChecked] = useState(false);

  const check = () => {
    const correct = blankIndices.every(i => normalize(answers[i] || "") === normalize(words[i]));
    setChecked(true);
    onResult(correct);
  };

  return (
    <div className="ex-area">
      <p className="kr-hint">{sentence.kr || "🇺🇸 영어 문장을 완성하세요"}</p>
      <div className="blank-sentence">
        {words.map((word, i) =>
          blankIndices.includes(i) ? (
            <input key={i} type="text"
              className={"blank-input" + (checked ? (normalize(answers[i] || "") === normalize(word) ? " correct" : " wrong") : "")}
              style={{ width: Math.max(word.length * 11, 50) + "px" }}
              value={answers[i] || ""}
              onChange={e => setAnswers({ ...answers, [i]: e.target.value })}
              disabled={checked} placeholder="?" />
          ) : <span key={i} className="word">{word}</span>
        )}
      </div>
      {checked && <div className="answer-reveal">정답: {sentence.en}</div>}
      {!checked && <button className="check-btn" onClick={check}>확인하기</button>}
    </div>
  );
}

function OrderMode({ sentence, onResult }) {
  const words = sentence.en.split(" ");
  const [shuffled] = useState(() => shuffleArray(words.map((w, i) => ({ w, i }))));
  const [selected, setSelected] = useState([]);
  const [checked, setChecked] = useState(false);

  const toggle = (item) => {
    if (checked) return;
    if (selected.find(s => s.i === item.i)) setSelected(selected.filter(s => s.i !== item.i));
    else setSelected([...selected, item]);
  };

  const isCorrect = selected.map(s => s.w).join(" ") === sentence.en;

  return (
    <div className="ex-area">
      <p className="kr-hint">{sentence.kr || "🇺🇸 단어를 순서대로 배열하세요"}</p>
      <div className="order-selected">
        {selected.length === 0
          ? <span className="placeholder-text">단어를 눌러서 문장을 만들어보세요</span>
          : selected.map((item, idx) => <span key={idx} className="order-chip sel" onClick={() => toggle(item)}>{item.w}</span>)}
      </div>
      <div className="order-words">
        {shuffled.map(item => (
          <span key={item.i}
            className={"order-chip" + (selected.find(s => s.i === item.i) ? " used" : "") + (checked ? " disabled" : "")}
            onClick={() => toggle(item)}>{item.w}</span>
        ))}
      </div>
      {checked && <div className={"result-badge " + (isCorrect ? "correct" : "wrong")}>{isCorrect ? "✅ 정답!" : "❌ 정답: " + sentence.en}</div>}
      {!checked && selected.length > 0 && <button className="check-btn" onClick={() => { setChecked(true); onResult(isCorrect); }}>확인하기</button>}
    </div>
  );
}

function DictationMode({ sentence, onResult }) {
  const [input, setInput] = useState("");
  const [checked, setChecked] = useState(false);
  const [played, setPlayed] = useState(false);

  const speak = () => {
    const u = new SpeechSynthesisUtterance(sentence.en);
    u.lang = "en-US"; u.rate = 0.85;
    window.speechSynthesis.speak(u);
    setPlayed(true);
  };

  const isCorrect = normalize(input) === normalize(sentence.en);

  return (
    <div className="ex-area">
      <p className="kr-hint">{sentence.kr || "🎧 음성을 듣고 받아쓰세요"}</p>
      <button className="speak-btn" onClick={speak}>🔊 {played ? "다시 듣기" : "들어보기"}</button>
      <textarea className="typing-area" placeholder={played ? "들은 내용을 받아써보세요..." : "먼저 음성을 들어보세요"}
        value={input} onChange={e => setInput(e.target.value)} disabled={checked} rows={2} />
      {checked && <div className={"result-badge " + (isCorrect ? "correct" : "wrong")}>{isCorrect ? "✅ 정답!" : "❌ 정답: " + sentence.en}</div>}
      {!checked && played && <button className="check-btn" onClick={() => { setChecked(true); onResult(isCorrect); }}>확인하기</button>}
    </div>
  );
}

function TypingMode({ sentence, onResult }) {
  const [input, setInput] = useState("");
  const [checked, setChecked] = useState(false);
  const isCorrect = normalize(input) === normalize(sentence.en);

  return (
    <div className="ex-area">
      <p className="kr-hint">{sentence.kr || "⌨️ 영어 문장을 타이핑하세요"}</p>
      <p style={{ fontSize: 13, color: "#9fa8da", margin: 0, textAlign: "center" }}>한국어를 보고 영어로 타이핑하세요</p>
      <textarea className="typing-area" placeholder="영어 문장을 타이핑하세요..."
        value={input} onChange={e => setInput(e.target.value)} disabled={checked} rows={2} />
      {checked && <div className={"result-badge " + (isCorrect ? "correct" : "wrong")}>{isCorrect ? "✅ 정답!" : "❌ 정답: " + sentence.en}</div>}
      {!checked && <button className="check-btn" onClick={() => { setChecked(true); onResult(isCorrect); }}>확인하기</button>}
    </div>
  );
}

// ── 메인 앱 ──────────────────────────────────────────
export default function App() {
  const [lessons, setLessons] = useState(LESSONS);
  const [screen, setScreen] = useState("home"); // home | photo | modes | exercise | finish
  const [selectedLesson, setSelectedLesson] = useState(null);
  const [mode, setMode] = useState(null);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [score, setScore] = useState({ correct: 0, total: 0 });
  const [resultShown, setResultShown] = useState(false);
  const [exerciseKey, setExerciseKey] = useState(0);
  const [showAll, setShowAll] = useState(false);

  const lessonSentences = selectedLesson ? selectedLesson.sentences : [];
  const sentence = lessonSentences[currentIdx];

  const goHome = () => {
    setScreen("home"); setSelectedLesson(null); setMode(null);
    setCurrentIdx(0); setScore({ correct: 0, total: 0 });
    setResultShown(false); setShowAll(false);
  };

  const startLesson = (lesson) => {
    setSelectedLesson(lesson); setScreen("modes");
    setCurrentIdx(0); setScore({ correct: 0, total: 0 });
    setResultShown(false); setShowAll(false);
  };

  const startMode = (m) => {
    setMode(m); setScreen("exercise");
    setCurrentIdx(0); setScore({ correct: 0, total: 0 });
    setResultShown(false); setExerciseKey(0);
  };

  const handleResult = (correct) => {
    setScore(s => ({ correct: s.correct + (correct ? 1 : 0), total: s.total + 1 }));
    setResultShown(true);
  };

  const next = () => {
    if (currentIdx + 1 >= lessonSentences.length) { setScreen("finish"); }
    else { setCurrentIdx(i => i + 1); setResultShown(false); setExerciseKey(k => k + 1); }
  };

  const handlePhotoLesson = (newLesson) => {
    setLessons(prev => [...prev, newLesson]);
    startLesson(newLesson);
  };

  // 1. 홈 - 단원 선택
  if (screen === "home") return (
    <div style={S.root}>
      <div style={S.wrap}>
        <div style={S.tag}>영어 본문 외우기</div>
        <h1 style={S.title}>단원을 선택하세요</h1>
        <p style={S.sub}>교재 단원을 고르거나 새 자료를 추가하세요</p>

        {/* AI 사진 추가 버튼 */}
        <button style={S.photoBtn} onClick={() => setScreen("photo")}>
          <span style={{ fontSize: 28 }}>📸</span>
          <div>
            <div style={{ fontWeight: 800, fontSize: 15 }}>AI로 새 자료 추가</div>
            <div style={{ fontSize: 12, opacity: 0.85 }}>사진 찍어서 자동 추출 ✨</div>
          </div>
        </button>

        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {lessons.map(lesson => (
            <button key={lesson.id} style={S.lessonCard} onClick={() => startLesson(lesson)}>
              <div style={S.lessonNum}>{typeof lesson.id === "number" && lesson.id <= 2 ? "Lesson " + lesson.id : "📝 내 자료"}</div>
              <div style={S.lessonTitle}>{lesson.title}</div>
              <div style={S.lessonSub}>{lesson.subtitle} · {lesson.sentences.length}문장</div>
            </button>
          ))}
        </div>
      </div>
      <style>{css}</style>
    </div>
  );

  // 2. 사진 업로드
  if (screen === "photo") return (
    <div style={S.root}>
      <PhotoUploader onDone={handlePhotoLesson} onBack={goHome} />
      <style>{css}</style>
    </div>
  );

  // 3. 모드 선택
  if (screen === "modes") return (
    <div style={S.root}>
      <div style={S.wrap}>
        <button style={S.backBtn} onClick={goHome}>← 단원 선택</button>
        <div style={S.tag}>Lesson</div>
        <h1 style={S.title}>{selectedLesson.title}</h1>
        <p style={S.sub}>{selectedLesson.subtitle}</p>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20 }}>
          {MODES.map(m => (
            <button key={m.id} style={S.modeCard} onClick={() => startMode(m.id)}>
              <span style={{ fontSize: 32 }}>{m.emoji}</span>
              <span style={{ fontSize: 14, fontWeight: 700, color: "#3949ab" }}>{m.label}</span>
            </button>
          ))}
        </div>
        <button style={S.outlineBtn} onClick={() => setShowAll(!showAll)}>
          {showAll ? "▲ 본문 닫기" : "📖 전체 본문 보기"}
        </button>
        {showAll && (
          <div style={S.allList}>
            {lessonSentences.map(s => (
              <div key={s.id} style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                <span style={S.numDot}>{s.id}</span>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: "#1a237e" }}>{s.en}</div>
                  <div style={{ fontSize: 12, color: "#7986cb" }}>{s.kr}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <style>{css}</style>
    </div>
  );

  // 4. 완료
  if (screen === "finish") {
    const pct = Math.round((score.correct / score.total) * 100);
    return (
      <div style={S.root}>
        <div style={{ ...S.wrap, textAlign: "center", paddingTop: 60 }}>
          <div style={{ fontSize: 64 }}>{pct >= 80 ? "🏆" : pct >= 50 ? "👍" : "💪"}</div>
          <h2 style={{ ...S.title, marginTop: 12 }}>완료!</h2>
          <div style={{ fontSize: 48, fontWeight: 900, color: "#4f7cff", margin: "8px 0 4px" }}>{score.correct} / {score.total}</div>
          <div style={{ fontSize: 20, color: "#7986cb", marginBottom: 16 }}>{pct}점</div>
          <p style={{ fontSize: 16, color: "#5c6bc0", marginBottom: 28 }}>
            {pct >= 80 ? "훌륭해요! 본문을 잘 외웠네요!" : pct >= 50 ? "잘 했어요! 조금 더 연습해봐요." : "다시 한번 도전해봐요!"}
          </p>
          <button style={{ ...S.bigBtn, marginBottom: 12 }} onClick={() => startMode(mode)}>같은 모드 다시</button>
          <button style={S.outlineBtn} onClick={() => setScreen("modes")}>다른 모드 선택</button>
          <button style={S.outlineBtn} onClick={goHome}>단원 선택으로</button>
        </div>
        <style>{css}</style>
      </div>
    );
  }

  // 5. 연습
  const progress = (currentIdx / lessonSentences.length) * 100;
  const currentMode = MODES.find(m => m.id === mode);
  return (
    <div style={S.root}>
      <div style={{ maxWidth: 480, margin: "0 auto" }}>
        <div style={S.header}>
          <button style={S.backBtn2} onClick={() => setScreen("modes")}>← 모드 선택</button>
          <span style={{ fontSize: 13, fontWeight: 700, color: "#3949ab" }}>{currentMode.emoji} {currentMode.label}</span>
          <span style={{ fontSize: 13, fontWeight: 700, color: "#43a047" }}>✅ {score.correct}/{score.total}</span>
        </div>
        <div style={S.progressBar}><div style={{ ...S.progressFill, width: progress + "%" }} /></div>
        <div style={S.card}>
          <div style={{ fontSize: 12, color: "#9fa8da", fontWeight: 600, marginBottom: 12 }}>{currentIdx + 1} / {lessonSentences.length}</div>
          {mode === "blank" && <BlankMode key={exerciseKey} sentence={sentence} onResult={handleResult} />}
          {mode === "order" && <OrderMode key={exerciseKey} sentence={sentence} onResult={handleResult} />}
          {mode === "dictation" && <DictationMode key={exerciseKey} sentence={sentence} onResult={handleResult} />}
          {mode === "typing" && <TypingMode key={exerciseKey} sentence={sentence} onResult={handleResult} />}
          {resultShown && (
            <button style={{ ...S.bigBtn, marginTop: 20 }} onClick={next}>
              {currentIdx + 1 >= lessonSentences.length ? "결과 보기 🎉" : "다음 문장 →"}
            </button>
          )}
        </div>
      </div>
      <style>{css}</style>
    </div>
  );
}

const S = {
  root: { minHeight: "100vh", background: "#f0f4ff", fontFamily: "'Noto Sans KR', sans-serif", padding: "0 0 40px" },
  wrap: { maxWidth: 480, margin: "0 auto", padding: "32px 20px 20px" },
  tag: { display: "inline-block", background: "#4f7cff", color: "#fff", borderRadius: 20, padding: "4px 14px", fontSize: 13, fontWeight: 700, marginBottom: 12 },
  title: { fontSize: 26, fontWeight: 900, color: "#1a237e", lineHeight: 1.25, margin: "0 0 8px" },
  sub: { fontSize: 14, color: "#5c6bc0", marginBottom: 24, lineHeight: 1.6 },
  photoBtn: { width: "100%", background: "linear-gradient(135deg, #4f7cff, #7c4dff)", color: "#fff", border: "none", borderRadius: 16, padding: "18px 20px", display: "flex", alignItems: "center", gap: 16, cursor: "pointer", marginBottom: 20, textAlign: "left" },
  lessonCard: { background: "#fff", border: "2px solid #e8eaf6", borderRadius: 16, padding: "18px", textAlign: "left", cursor: "pointer", width: "100%" },
  lessonNum: { fontSize: 12, fontWeight: 700, color: "#4f7cff", marginBottom: 4 },
  lessonTitle: { fontSize: 16, fontWeight: 800, color: "#1a237e", marginBottom: 4 },
  lessonSub: { fontSize: 13, color: "#7986cb" },
  modeCard: { background: "#fff", border: "2px solid #e8eaf6", borderRadius: 16, padding: "20px 12px", display: "flex", flexDirection: "column", alignItems: "center", gap: 8, cursor: "pointer" },
  outlineBtn: { width: "100%", background: "transparent", border: "2px solid #c5cae9", borderRadius: 12, padding: "10px", fontSize: 14, color: "#5c6bc0", cursor: "pointer", marginBottom: 10 },
  allList: { background: "#fff", borderRadius: 16, padding: "12px 16px", display: "flex", flexDirection: "column", gap: 12 },
  numDot: { minWidth: 24, height: 24, background: "#4f7cff", color: "#fff", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700, marginTop: 2, flexShrink: 0 },
  backBtn: { background: "none", border: "none", fontSize: 14, color: "#5c6bc0", cursor: "pointer", fontWeight: 600, padding: "0 0 16px", display: "block" },
  backBtn2: { background: "none", border: "none", fontSize: 14, color: "#5c6bc0", cursor: "pointer", fontWeight: 600 },
  header: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "16px 20px 8px", background: "#fff", borderBottom: "1px solid #e8eaf6" },
  progressBar: { height: 4, background: "#e8eaf6" },
  progressFill: { height: "100%", background: "linear-gradient(90deg, #4f7cff, #7c4dff)", transition: "width 0.4s" },
  card: { margin: "20px 16px", background: "#fff", borderRadius: 20, padding: "24px 20px", boxShadow: "0 4px 20px rgba(79,124,255,0.1)" },
  bigBtn: { width: "100%", background: "linear-gradient(135deg, #4f7cff, #7c4dff)", color: "#fff", border: "none", borderRadius: 14, padding: "14px", fontSize: 16, fontWeight: 700, cursor: "pointer" },
  uploadBox: { border: "3px dashed #c5cae9", borderRadius: 20, padding: "48px 20px", textAlign: "center", cursor: "pointer", background: "#fff", marginBottom: 16 },
  editCard: { background: "#f8f9ff", border: "1px solid #e8eaf6", borderRadius: 12, padding: "14px" },
  editInput: { width: "100%", border: "1px solid #c5cae9", borderRadius: 8, padding: "8px 12px", fontSize: 14, color: "#1a237e", outline: "none", background: "#fff" },
  titleInput: { width: "100%", border: "2px solid #c5cae9", borderRadius: 12, padding: "12px", fontSize: 15, fontWeight: 600, color: "#1a237e", outline: "none", marginBottom: 14 },
  errorBox: { background: "#ffebee", color: "#c62828", borderRadius: 10, padding: "10px 14px", fontSize: 14, marginBottom: 12 },
};

const css = `
  @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;600;700;900&display=swap');
  * { box-sizing: border-box; }
  .ex-area { display: flex; flex-direction: column; gap: 14px; }
  .kr-hint { font-size: 15px; color: #5c6bc0; margin: 0; line-height: 1.6; background: #f5f7ff; padding: 10px 14px; border-radius: 10px; border-left: 3px solid #7c4dff; }
  .blank-sentence { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; line-height: 2.4; font-size: 16px; color: #1a237e; font-weight: 600; }
  .blank-input { border: 2px solid #c5cae9; border-radius: 8px; padding: 4px 6px; font-size: 15px; font-weight: 700; color: #1a237e; outline: none; text-align: center; }
  .blank-input:focus { border-color: #4f7cff; }
  .blank-input.correct { border-color: #43a047; background: #e8f5e9; color: #2e7d32; }
  .blank-input.wrong { border-color: #e53935; background: #ffebee; color: #c62828; }
  .answer-reveal { font-size: 14px; color: #43a047; font-weight: 600; background: #e8f5e9; padding: 10px 14px; border-radius: 10px; }
  .check-btn { background: #4f7cff; color: #fff; border: none; border-radius: 12px; padding: 12px; font-size: 15px; font-weight: 700; cursor: pointer; width: 100%; }
  .order-selected { min-height: 48px; background: #f0f4ff; border-radius: 12px; padding: 10px; display: flex; flex-wrap: wrap; gap: 6px; align-items: center; border: 2px dashed #c5cae9; }
  .placeholder-text { font-size: 13px; color: #9fa8da; }
  .order-words { display: flex; flex-wrap: wrap; gap: 8px; }
  .order-chip { background: #fff; border: 2px solid #c5cae9; border-radius: 20px; padding: 6px 14px; font-size: 14px; font-weight: 600; color: #3949ab; cursor: pointer; user-select: none; }
  .order-chip.sel { background: #4f7cff; color: #fff; border-color: #4f7cff; }
  .order-chip.used { opacity: 0.3; pointer-events: none; }
  .order-chip.disabled { pointer-events: none; }
  .result-badge { padding: 12px 16px; border-radius: 12px; font-size: 14px; font-weight: 700; line-height: 1.5; }
  .result-badge.correct { background: #e8f5e9; color: #2e7d32; }
  .result-badge.wrong { background: #ffebee; color: #c62828; }
  .speak-btn { background: linear-gradient(135deg, #4f7cff, #7c4dff); color: #fff; border: none; border-radius: 12px; padding: 12px 20px; font-size: 16px; font-weight: 700; cursor: pointer; width: 100%; }
  .typing-area { width: 100%; border: 2px solid #c5cae9; border-radius: 12px; padding: 12px; font-size: 15px; color: #1a237e; outline: none; resize: none; font-family: inherit; line-height: 1.6; }
  .typing-area:focus { border-color: #4f7cff; }
`;
